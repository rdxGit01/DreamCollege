let collegeData = [];

async function fetchColleges() {
  const res = await fetch("http://localhost:4000/colleges");
  collegeData = await res.json();
  initializeFilters();
}

const cardsContainer = document.getElementById('college-cards-container');
const courseFilter = document.getElementById('course-filter');
const feeRangeFilter = document.getElementById('fee-range-filter');
const ratingFilter = document.getElementById('rating-filter');
const feeDisplay = document.getElementById('fee-display');
const applyBtn = document.getElementById('apply-filter-btn');
const maxRankFilter = document.getElementById('max-rank-filter');
const naacGradeFilter = document.getElementById('naac-grade-filter');
const cityFilter = document.getElementById('city-filter');

function renderColleges(colleges) {
  cardsContainer.innerHTML = '';

  if (!colleges.length) {
    cardsContainer.innerHTML = '<p>No colleges match your filter criteria.</p>';
    return;
  }

  colleges.forEach(c => {
    const card = document.createElement('div');
    card.classList.add('college-card');
    card.innerHTML = `
      <h3>${c.name}</h3>
      <p>City: ${c.city}</p>
      <p>Courses: ${c.courses.join(', ')}</p>
      <p>Fee: ₹${c.fee.toLocaleString('en-IN')}</p>
      <p>NAAC: ${c.naac_grade}</p>
      <p>Rating: ⭐ ${c.rating}</p>
    `;
    cardsContainer.appendChild(card);
  });
}

function applyFilters() {
  const filtered = collegeData.filter(c => {
    return (!courseFilter.value || c.courses.includes(courseFilter.value))
      && c.fee <= parseInt(feeRangeFilter.value)
      && c.rating >= parseFloat(ratingFilter.value)
      && c.ranking <= parseInt(maxRankFilter.value)
      && (!naacGradeFilter.value || c.naac_grade === naacGradeFilter.value)
      && (!cityFilter.value || c.city === cityFilter.value);
  });

  renderColleges(filtered);
}

function initializeFilters() {
  feeRangeFilter.addEventListener("input", () => {
    feeDisplay.textContent =
      `Max: ₹${parseInt(feeRangeFilter.value).toLocaleString('en-IN')}`;
  });

  applyBtn.addEventListener("click", applyFilters);
  renderColleges(collegeData);
}

document.addEventListener("DOMContentLoaded", fetchColleges);
