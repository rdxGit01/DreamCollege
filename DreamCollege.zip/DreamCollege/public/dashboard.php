<?php
// Header first (starts session inside)
include 'partials/header.php';

// Auth guard
require_once __DIR__ . '/../src/middleware/auth_guard.php';

// DB connection
require_once __DIR__ . '/../config/db_mysql.php';

// Controller
require_once __DIR__ . '/../src/controllers/UserController.php';

$user_id = $_SESSION['user_id'];

$userController = new UserController();
$result = $userController->getUserById($user_id);
$user = mysqli_fetch_assoc($result);

// ================= UPDATE PROFILE =================
if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    $name = mysqli_real_escape_string($conn, $_POST['name']);
    $profession = mysqli_real_escape_string($conn, $_POST['profession']);
    $qualification = mysqli_real_escape_string($conn, $_POST['qualification']);
    $address = mysqli_real_escape_string($conn, $_POST['address']);
    $about = mysqli_real_escape_string($conn, $_POST['about']);

    $photoName = $user['photo'];

    if (!empty($_FILES['photo']['name'])) {
        $photoName = time() . '_' . $_FILES['photo']['name'];
        move_uploaded_file(
            $_FILES['photo']['tmp_name'],
            "assets/images/$photoName"
        );
    }

    mysqli_query($conn, "
        UPDATE users SET
            name='$name',
            profession='$profession',
            qualification='$qualification',
            address='$address',
            about='$about',
            photo='$photoName'
        WHERE id=$user_id
    ");

    header("Location: dashboard.php");
    exit;
}

// ================= BOOKMARKED COLLEGES =================
$bookmarks = mysqli_query($conn, "
    SELECT c.*
    FROM colleges c
    JOIN bookmarks b ON c.id = b.college_id
    WHERE b.user_id = $user_id
");
?>

<link rel="stylesheet" href="assets/css/dashboard.css">

<div class="dashboard">

    <!-- SIDEBAR -->
    <div class="sidebar">
        <h2>Dashboard</h2>
        <a href="dashboard.php">Profile</a>
        <a href="#bookmarks">Bookmarked Colleges</a>
        <a href="index.php">Home</a>
        <a href="logout.php">Logout</a>
    </div>

    <!-- MAIN CONTENT -->
    <div class="content">
        <h1>Welcome <?= htmlspecialchars($user['name'] ?: 'User'); ?></h1>

        <div class="profile-card">

            <?php if (!empty($user['photo'])) { ?>
                <img src="assets/images/<?= $user['photo']; ?>" class="profile-img">
            <?php } ?>

            <form method="POST" enctype="multipart/form-data">

                <input type="text" name="name" placeholder="Full Name"
                    value="<?= htmlspecialchars($user['name'] ?? '') ?>">

                <input type="text" name="profession" placeholder="Profession"
                    value="<?= htmlspecialchars($user['profession'] ?? '') ?>">

                <input type="text" name="qualification" placeholder="Qualification"
                    value="<?= htmlspecialchars($user['qualification'] ?? '') ?>">

                <textarea name="address" placeholder="Address"><?= htmlspecialchars($user['address'] ?? '') ?></textarea>

                <textarea name="about" placeholder="About you"><?= htmlspecialchars($user['about'] ?? '') ?></textarea>

                <label>Profile Photo</label>
                <input type="file" name="photo">

                <button type="submit">Save Profile</button>

            </form>
        </div>

        <h2 id="bookmarks">Bookmarked Colleges</h2>

        <div class="college-container">
            <?php if (mysqli_num_rows($bookmarks) > 0) { ?>
                <?php while ($c = mysqli_fetch_assoc($bookmarks)) { ?>
                    <div class="college-card">
                        <img src="assets/images/<?= $c['image']; ?>">
                        <h3><?= htmlspecialchars($c['name']); ?></h3>
                        <p><?= htmlspecialchars($c['location']); ?></p>
                        <a href="college.php?id=<?= $c['id']; ?>">View Details</a>
                    </div>
                <?php } ?>
            <?php } else { ?>
                <p>No bookmarked colleges yet.</p>
            <?php } ?>
        </div>

    </div>
</div>

<?php include 'partials/footer.php'; ?>
