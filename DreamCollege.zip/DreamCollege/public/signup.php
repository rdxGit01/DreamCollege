<?php
session_start();
include __DIR__ . '/partials/header.php';
?>

<main class="auth-container">
  <div class="auth-box">
    <h2>Create Your Account 🎓</h2>

    <?php if (!empty($_SESSION['error'])): ?>
      <div class="error-message">
        <?= htmlspecialchars($_SESSION['error']); unset($_SESSION['error']); ?>
      </div>
    <?php endif; ?>

    <?php if (!empty($_SESSION['success'])): ?>
      <div class="success-message">
        <?= htmlspecialchars($_SESSION['success']); unset($_SESSION['success']); ?>
      </div>
    <?php endif; ?>

    <form method="post" action="/DreamCollege/src/auth/register.php" class="auth-form">
      <label for="name">Full Name</label>
      <input type="text" id="name" name="name" placeholder="Enter your name" required>

      <label for="email">Email</label>
      <input type="email" id="email" name="email" placeholder="Enter your email" required>

      <label for="password">Password</label>
      <input type="password" id="password" name="password" placeholder="Create a password" required>

      <label for="confirm">Confirm Password</label>
      <input type="password" id="confirm" name="confirm" placeholder="Confirm password" required>

      <button type="submit" class="btn-primary">Sign Up</button>
    </form>

    <div class="auth-footer">
      <p>Already have an account? <a href="/DreamCollege/public/login.php">Login</a></p>
      <a href="/DreamCollege/public/index.php" class="back-link">← Back to Home</a>
    </div>
  </div>
</main>

<?php include __DIR__ . '/partials/footer.php'; ?>
