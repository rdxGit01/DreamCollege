<?php
include 'partials/header.php';

require_once __DIR__ . '/../src/controllers/CollegeController.php';

$controller = new CollegeController();

/* Safe GET values */
$search = $_GET['search'] ?? '';

/* Fetch colleges */
if (!empty($_GET)) {
    $colleges = $controller->getFilteredColleges($_GET);
} else {
    $colleges = $controller->getAllColleges();
}

/* TEMP: course list (will be moved later) */
$coursesList = ['B.Tech', 'M.Tech', 'MBA', 'BCA', 'MCA', 'PhD']; // static list for UI

?>

<h1 style="text-align:center;">Dream College</h1>

<!-- SEARCH BAR -->
<form method="GET" style="text-align:center;margin:20px;">
    <input
        type="text"
        name="search"
        placeholder="Search colleges, location or course..."
        value="<?= htmlspecialchars($search); ?>"
        style="width:300px;padding:10px;"
    >
    <button type="submit" style="padding:10px;">Search</button>
</form>

<div style="display:flex;gap:20px;padding:20px;">

    <!-- FILTER SIDEBAR -->
   <form method="GET" id="filterForm" style="width:260px;background:#fff;padding:15px;border-radius:8px;">


        <h3>Filters</h3>

        <label>Course</label><br>
        <select name="course" style="width:100%;">
            <option value="">Any</option>
            <?php foreach ($coursesList as $c) { ?>
                <option value="<?= $c ?>" <?= (($_GET['course'] ?? '') === $c) ? 'selected' : '' ?>>
                    <?= $c ?>
                </option>
            <?php } ?>
        </select><br><br>

        <label>Max NIRF Rank</label><br>
        <input type="number" name="nirf" value="<?= $_GET['nirf'] ?? '' ?>"><br><br>

        <label>NAAC Grade</label><br>
        <select name="naac">
            <option value="">Any</option>
            <?php foreach (['A++','A+','A'] as $g) { ?>
                <option value="<?= $g ?>" <?= (($_GET['naac'] ?? '') === $g) ? 'selected' : '' ?>>
                    <?= $g ?>
                </option>
            <?php } ?>
        </select><br><br>

        <label>Location</label><br>
        <input type="text" name="location" value="<?= $_GET['location'] ?? '' ?>"><br><br>

        <label>Max Fees (₹)</label><br>
        <input type="number" name="fees" value="<?= $_GET['fees'] ?? '' ?>"><br><br>

        <button type="submit">Apply Filters</button>
    </form>

    <!-- COLLEGE CARDS -->
    <div style="flex:1;">
        <div class="college-container" id="collegeContainer">


            <?php if ($colleges && mysqli_num_rows($colleges) > 0) { ?>
                <?php while ($row = mysqli_fetch_assoc($colleges)) { ?>
                    <div class="college-card">
                        <img src="assets/images/<?= $row['image']; ?>" alt="<?= $row['name']; ?>">
                        <h3><?= $row['name']; ?></h3>
                        <p><?= $row['location']; ?>, <?= $row['state']; ?></p>
                        <p>NIRF Rank: <?= $row['nirf_rank']; ?></p>
                        <p>Fees: ₹<?= number_format($row['fees']); ?></p>
                        <a href="college.php?id=<?= $row['id']; ?>">View Details</a>

                        <?php if (isset($_SESSION['user_id'])) { ?>
                            <form method="POST" action="bookmark.php">
                                <input type="hidden" name="college_id" value="<?= $row['id']; ?>">
                                <button type="submit">⭐ Bookmark</button>
                            </form>
                        <?php } ?>
                    </div>
                <?php } ?>
            <?php } else { ?>
                <p style="font-size:18px;padding:20px;">
                    ❌ No colleges found for selected filters.
                </p>
            <?php } ?>

        </div>
    </div>

</div>

<?php include 'partials/footer.php'; ?>