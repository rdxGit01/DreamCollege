<?php
require_once __DIR__ . '/../config/db_mysql.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    $name = mysqli_real_escape_string($conn, $_POST['name']);
    $email = mysqli_real_escape_string($conn, $_POST['email']);
    $password = password_hash($_POST['password'], PASSWORD_DEFAULT);

    mysqli_query($conn, "
        INSERT INTO users (name, email, password)
        VALUES ('$name', '$email', '$password')
    ");

    header("Location: login.php");
    exit;
}
?>

<link rel="stylesheet" href="assets/css/auth-ui.css">

<div class="auth-wrapper">
    <div class="auth-card">
        <h2>Create Your Account 🎓</h2>

        <form method="POST">

            <label>Full Name</label>
            <input type="text" name="name" placeholder="Enter your name" required>

            <label>Email</label>
            <input type="email" name="email" placeholder="Enter your email" required>

            <label>Password</label>
            <input type="password" name="password" placeholder="Create a password" required>

            <button type="submit">Sign Up</button>
        </form>

        <p>Already have an account? <a href="login.php">Login</a></p>

        <div class="back-home">
            <a href="index.php">← Back to Home</a>
        </div>
    </div>
</div>
