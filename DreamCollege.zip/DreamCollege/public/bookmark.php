<?php
session_start();
require_once __DIR__ . '/../config/db_mysql.php';

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit;
}

$user_id = $_SESSION['user_id'];
$college_id = intval($_POST['college_id']);

mysqli_query($conn, "
    INSERT IGNORE INTO bookmarks (user_id, college_id)
    VALUES ($user_id, $college_id)
");

header("Location: index.php");
exit;
