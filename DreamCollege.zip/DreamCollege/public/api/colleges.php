<?php
header('Content-Type: application/json');
require_once __DIR__ . '/../../config/db_mysql.php';

$sql = "SELECT * FROM colleges";
$params = [];
$conditions = [];

// Apply filters
if (!empty($_GET['course'])) {
  $conditions[] = "FIND_IN_SET(?, courses)";
  $params[] = $_GET['course'];
}
if (!empty($_GET['city'])) {
  $conditions[] = "city = ?";
  $params[] = $_GET['city'];
}
if (!empty($_GET['naac'])) {
  $conditions[] = "naacGrade = ?";
  $params[] = $_GET['naac'];
}
if (!empty($_GET['maxFee'])) {
  $conditions[] = "fee <= ?";
  $params[] = (int)$_GET['maxFee'];
}
if (!empty($_GET['rating'])) {
  $conditions[] = "rating >= ?";
  $params[] = (float)$_GET['rating'];
}
if (!empty($_GET['maxRank'])) {
  $conditions[] = "ranking <= ?";
  $params[] = (int)$_GET['maxRank'];
}

if ($conditions) {
  $sql .= " WHERE " . implode(" AND ", $conditions);
}

$stmt = $pdo->prepare($sql);
$stmt->execute($params);
$colleges = $stmt->fetchAll(PDO::FETCH_ASSOC);

echo json_encode($colleges, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
