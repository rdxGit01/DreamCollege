<?php
include 'partials/header.php';
require_once __DIR__ . '/../src/controllers/CollegeController.php';

if (!isset($_GET['id'])) {
    die("College not found");
}

$controller = new CollegeController();
$result = $controller->getCollegeById($_GET['id']);
$college = mysqli_fetch_assoc($result);

if (!$college) {
    die("College not found");
}
?>

<title><?= htmlspecialchars($college['name']); ?></title>
<link rel="stylesheet" href="assets/css/college-details.css">

<div class="college-details-wrapper">

    <div class="college-details-card">

        <img 
            src="assets/images/<?= htmlspecialchars($college['image']); ?>" 
            alt="<?= htmlspecialchars($college['name']); ?>" 
            class="college-banner"
        >

        <div class="college-content">

            <h1><?= htmlspecialchars($college['name']); ?></h1>

            <p class="college-location">
                📍 <?= htmlspecialchars($college['location']); ?>, <?= htmlspecialchars($college['state']); ?>
            </p>

            <div class="college-stats">
                <div><strong>NIRF Rank</strong><span><?= $college['nirf_rank']; ?></span></div>
                <div><strong>NAAC Grade</strong><span><?= htmlspecialchars($college['naac_grade']); ?></span></div>
                <div><strong>Fees</strong><span>₹<?= number_format($college['fees']); ?></span></div>
            </div>

            <div class="college-section">
                <h3>🎓 Courses Offered</h3>
                <p><?= htmlspecialchars($college['courses']); ?></p>
            </div>

            <div class="college-section">
                <h3>📘 About the College</h3>
                <p><?= nl2br(htmlspecialchars($college['description'])); ?></p>
            </div>

            <?php if (!empty($college['website'])) { ?>
    <a 
        href="<?= htmlspecialchars($college['website']); ?>" 
        target="_blank" 
        class="apply-btn"
    >
        🚀 Apply Now
    </a>
<?php } ?>

            <a href="index.php" class="back-btn">← Back to Colleges</a>

        </div>

    </div>

</div>

<?php include 'partials/footer.php'; ?>
