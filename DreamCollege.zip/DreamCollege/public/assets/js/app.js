// =========================
// 1. Fetch Data from Backend
// =========================
let collegeData = [];

async function loadColleges(params = {}) {
  try {
    const query = new URLSearchParams(params).toString();
    const res = await fetch(`/DreamCollege/public/api/colleges.php?${query}`);
    if (!res.ok) throw new Error(`Server error: ${res.status}`);
    collegeData = await res.json();
    renderColleges(collegeData);
  } catch (err) {
    console.error("Failed to load colleges:", err);
    cardsContainer.innerHTML = '<p class="error-message">⚠️ Unable to fetch college data. Please try again later.</p>';
  }
}

// =========================
// 2. DOM Elements
// =========================
const cardsContainer = document.getElementById('college-cards-container');
const courseFilter = document.getElementById('course-filter');
const feeRangeFilter = document.getElementById('fee-range-filter');
const ratingFilter = document.getElementById('rating-filter');
const feeDisplay = document.getElementById('fee-display');
const applyBtn = document.getElementById('apply-filter-btn');
const searchInput = document.getElementById('global-search');
const maxRankFilter = document.getElementById('max-rank-filter');
const naacGradeFilter = document.getElementById('naac-grade-filter');
const cityFilter = document.getElementById('city-filter');

// =========================
// 3. Rendering Function
// =========================
function renderColleges(colleges) {
  cardsContainer.innerHTML = ''; 

  if (!colleges || colleges.length === 0) {
    cardsContainer.innerHTML = '<p>No colleges match your filter criteria.</p>';
    return;
  }

  colleges.forEach(college => {
    const card = document.createElement('article');
    card.classList.add('college-card');

    // Normalize courses field
    let courses = Array.isArray(college.courses) 
      ? college.courses 
      : (college.courses || "").split(',').map(c => c.trim());

    // Clickable card → details page
    card.addEventListener('click', () => {
      window.location.href = `/DreamCollege/public/college.php?id=${college.id}`;
    });

    card.innerHTML = `
      <img src="${college.image_url}" alt="${college.name}" class="college-img">
      <h3>${college.name}</h3>
      <p><strong>NIRF Rank:</strong> #${college.ranking} | <strong>NAAC:</strong> ${college.naacGrade || 'N/A'}</p>
      <p><strong>Courses:</strong> ${courses.join(', ')}</p>
      <p><strong>Fee (Annual):</strong> ₹${parseInt(college.fee).toLocaleString('en-IN')}</p>
      <p><strong>Placement Rate:</strong> ${college.placement}%</p>
      <p><strong>City:</strong> ${college.city}</p>
      <p><span class="rating-pill">⭐ ${college.rating} / 5.0</span></p>
      <a href="/DreamCollege/public/college.php?id=${college.id}" class="details-link">View Details</a>
    `;
    cardsContainer.appendChild(card);
  });
}

// =========================
// 4. Apply Filters Function
// =========================
function applyFilters() {
  const params = {
    course: courseFilter?.value || '',
    maxFee: feeRangeFilter?.value || '',
    rating: ratingFilter?.value || '',
    maxRank: maxRankFilter?.value || '',
    naac: naacGradeFilter?.value || '',
    city: cityFilter?.value || '',
    search: searchInput ? searchInput.value.trim() : ''
  };
  loadColleges(params);
}

// =========================
// 5. Initialization
// =========================
function initializeFilters() {
  if (feeRangeFilter && feeDisplay) {
    feeRangeFilter.addEventListener('input', () => {
      feeDisplay.textContent = `Max: ₹${parseInt(feeRangeFilter.value).toLocaleString('en-IN')}`;
    });
    feeDisplay.textContent = `Max: ₹${parseInt(feeRangeFilter.value).toLocaleString('en-IN')}`;
  }

  if (applyBtn) applyBtn.addEventListener('click', applyFilters);

  const searchBtn = document.getElementById('global-search-btn');
  if (searchBtn) searchBtn.addEventListener('click', applyFilters);

  // Initial load
  loadColleges();
}

// =========================
// 6. Info Menu Toggle
// =========================
function toggleInfoMenu() {
  const dropdown = document.getElementById('infoDropdown');
  if (dropdown) {
    dropdown.style.display = dropdown.style.display === 'flex' ? 'none' : 'flex';
  }
}

// =========================
// 7. Run Initialization
// =========================
document.addEventListener('DOMContentLoaded', initializeFilters);
