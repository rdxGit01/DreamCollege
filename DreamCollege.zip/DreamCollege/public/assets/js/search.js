document.addEventListener("DOMContentLoaded", () => {

    const form = document.getElementById("filterForm");
    const container = document.getElementById("collegeContainer");

    if (!form || !container) return;

    // Trigger search on input change
    form.querySelectorAll("input, select").forEach(el => {
        el.addEventListener("input", fetchColleges);
        el.addEventListener("change", fetchColleges);
    });

    function fetchColleges() {
        const params = new URLSearchParams(new FormData(form));

        fetch("../api/colleges.php?" + params.toString())
            .then(res => res.json())
            .then(data => {
                container.innerHTML = "";

                if (data.length === 0) {
                    container.innerHTML = "<p>❌ No colleges found.</p>";
                    return;
                }

                data.forEach(c => {
                    container.innerHTML += `
                        <div class="college-card">
                            <img src="assets/images/${c.image}" alt="${c.name}">
                            <h3>${c.name}</h3>
                            <p>${c.location}, ${c.state}</p>
                            <p>NIRF Rank: ${c.nirf_rank}</p>
                            <p>Fees: ₹${Number(c.fees).toLocaleString()}</p>
                            <a href="college.php?id=${c.id}">View Details</a>
                        </div>
                    `;
                });
            })
            .catch(() => {
                container.innerHTML = "<p>Error loading colleges.</p>";
            });
    }
});
