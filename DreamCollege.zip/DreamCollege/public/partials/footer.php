</main>

<footer class="site-footer">
    <p>© <?= date('Y') ?> Dream College. All rights reserved.</p>
</footer>

<!-- GLOBAL JS (empty for now, will use later) -->
<script src="<?= BASE_URL ?>assets/js/search.js"></script>
<script src="<?= BASE_URL ?>assets/js/filters.js"></script>
<script src="<?= BASE_URL ?>assets/js/dashboard.js"></script>

</body>
</html>
