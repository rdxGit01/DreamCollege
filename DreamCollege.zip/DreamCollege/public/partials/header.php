<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
require_once __DIR__ . '/../../config/env.php';
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Dream College</title>

    <!-- GLOBAL CSS -->
    <link rel="stylesheet" href="<?= BASE_URL ?>assets/css/base.css">
    <link rel="stylesheet" href="<?= BASE_URL ?>assets/css/layout.css">
    <link rel="stylesheet" href="<?= BASE_URL ?>assets/css/cards.css">
    <link rel="stylesheet" href="<?= BASE_URL ?>assets/css/filters.css">
    <link rel="stylesheet" href="<?= BASE_URL ?>assets/css/dashboard.css">
</head>
<body>

<header class="site-header">
    <div class="logo">DreamCollege</div>

    <nav class="nav-links">
        <a href="<?= BASE_URL ?>index.php">Home</a>

        <?php if (isset($_SESSION['user_id'])) { ?>
            <a href="<?= BASE_URL ?>dashboard.php">Dashboard</a>
            <a href="<?= BASE_URL ?>logout.php">Logout</a>
        <?php } else { ?>
            <a href="<?= BASE_URL ?>login.php">Login</a>
            <a href="<?= BASE_URL ?>register.php">Signup</a>
        <?php } ?>
    </nav>
</header>

<main class="main-content">
