<?php
// Preserve existing filter values (important for UX)
$selectedCourse   = $_GET['course']   ?? '';
$selectedNirf     = $_GET['nirf']     ?? '';
$selectedNaac     = $_GET['naac']     ?? '';
$selectedLocation = $_GET['location'] ?? '';
$selectedFees     = $_GET['fees']     ?? '';

// Static course list (can later be dynamic)
$coursesList = [
    'B.Tech',
    'M.Tech',
    'MBA',
    'BCA',
    'MCA',
    'BSc',
    'MSc',
    'BA',
    'MA'
];
?>

<form id="filterForm" class="filter-sidebar" method="GET">

    <h3>Filters</h3>

    <!-- COURSE -->
    <label>Course</label>
    <select name="course">
        <option value="">Any</option>
        <?php foreach ($coursesList as $course): ?>
            <option value="<?= $course ?>"
                <?= ($selectedCourse === $course) ? 'selected' : '' ?>>
                <?= $course ?>
            </option>
        <?php endforeach; ?>
    </select>

    <!-- NIRF -->
    <label>Max NIRF Rank</label>
    <input type="number"
           name="nirf"
           placeholder="e.g. 10"
           value="<?= htmlspecialchars($selectedNirf) ?>">

    <!-- NAAC -->
    <label>NAAC Grade</label>
    <select name="naac">
        <option value="">Any</option>
        <?php foreach (['A++','A+','A'] as $grade): ?>
            <option value="<?= $grade ?>"
                <?= ($selectedNaac === $grade) ? 'selected' : '' ?>>
                <?= $grade ?>
            </option>
        <?php endforeach; ?>
    </select>

    <!-- LOCATION -->
    <label>Location</label>
    <input type="text"
           name="location"
           placeholder="City or State"
           value="<?= htmlspecialchars($selectedLocation) ?>">

    <!-- FEES -->
    <label>Max Fees (₹)</label>
    <input type="number"
           name="fees"
           placeholder="e.g. 200000"
           value="<?= htmlspecialchars($selectedFees) ?>">

    <button type="submit">Apply Filters</button>

</form>

<div class="filter-box">
    <h3>Filters</h3>

    <label>Course</label>
    <select name="course">
        <option value="">Any</option>
        <?php foreach ($coursesList as $c) { ?>
            <option value="<?= $c ?>" <?= (($_GET['course'] ?? '') === $c) ? 'selected' : '' ?>>
                <?= $c ?>
            </option>
        <?php } ?>
    </select>

    <label>Max NIRF Rank</label>
    <input type="number" name="nirf" value="<?= $_GET['nirf'] ?? '' ?>">

    <label>NAAC Grade</label>
    <select name="naac">
        <option value="">Any</option>
        <option>A++</option>
        <option>A+</option>
        <option>A</option>
    </select>

    <label>Location</label>
    <input type="text" name="location" value="<?= $_GET['location'] ?? '' ?>">

    <label>Max Fees (₹)</label>
    <input type="number" name="fees" value="<?= $_GET['fees'] ?? '' ?>">

    <button type="submit">Apply Filters</button>
</div>
