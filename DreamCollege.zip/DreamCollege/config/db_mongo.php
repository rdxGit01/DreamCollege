<?php
// config/db_mongo.php
if (!class_exists(MongoDB\Client::class)) {
  // If missing driver, you can skip Mongo usage gracefully
  return null;
}
require_once __DIR__ . '/../vendor/autoload.php'; // if you use Composer for MongoDB library
$mongoClient = new MongoDB\Client($_ENV['MONGO_URI'] ?? 'mongodb://localhost:27017');
$mongoDb = $mongoClient->selectDatabase($_ENV['MONGO_DB'] ?? 'dreamcollege');
