<?php
define('BASE_URL', 'http://localhost/DreamCollege/public/');