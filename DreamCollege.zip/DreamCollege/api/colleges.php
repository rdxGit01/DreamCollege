<?php
require_once __DIR__ . '/../src/controllers/CollegeController.php';

header('Content-Type: application/json');

$controller = new CollegeController();

if (!empty($_GET)) {
    $result = $controller->getFilteredColleges($_GET);
} else {
    $result = $controller->getAllColleges();
}

$data = [];
if ($result) {
    while ($row = mysqli_fetch_assoc($result)) {
        $data[] = $row;
    }
}

echo json_encode($data);
