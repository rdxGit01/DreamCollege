<?php
session_start();
require_once __DIR__ . '/../src/controllers/UserController.php';

header('Content-Type: application/json');

if (!isset($_SESSION['user_id'])) {
    echo json_encode(['error' => 'Unauthorized']);
    exit;
}

$controller = new UserController();
$result = $controller->getUserById($_SESSION['user_id']);
$user = mysqli_fetch_assoc($result);

echo json_encode($user);
