<?php
require_once __DIR__ . '/../config/db_mysql.php';

$where = [];

if (!empty($_GET['search'])) {
    $s = mysqli_real_escape_string($conn, $_GET['search']);
    $where[] = "(name LIKE '%$s%' OR location LIKE '%$s%' OR courses LIKE '%$s%')";
}

if (!empty($_GET['course'])) {
    $course = mysqli_real_escape_string($conn, $_GET['course']);
    $where[] = "courses LIKE '%$course%'";
}

if (!empty($_GET['nirf'])) {
    $where[] = "nirf_rank <= " . intval($_GET['nirf']);
}

if (!empty($_GET['naac'])) {
    $where[] = "naac_grade = '" . mysqli_real_escape_string($conn, $_GET['naac']) . "'";
}

if (!empty($_GET['location'])) {
    $where[] = "location LIKE '%" . mysqli_real_escape_string($conn, $_GET['location']) . "%'";
}

if (!empty($_GET['fees'])) {
    $where[] = "fees <= " . intval($_GET['fees']);
}

$sql = "SELECT * FROM colleges";
if ($where) {
    $sql .= " WHERE " . implode(" AND ", $where);
}

$result = mysqli_query($conn, $sql);

$data = [];
while ($row = mysqli_fetch_assoc($result)) {
    $data[] = $row;
}

echo json_encode($data);
