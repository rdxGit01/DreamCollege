<?php
header('Content-Type: application/json');

echo json_encode([
    'courses' => ['B.Tech', 'M.Tech', 'MBA', 'BCA', 'MCA', 'PhD'],
    'naac' => ['A++', 'A+', 'A']
]);
