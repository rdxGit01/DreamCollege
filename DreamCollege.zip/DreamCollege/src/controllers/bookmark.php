<?php
session_start();
require_once __DIR__ . '/../../config/db_mysql.php';

if (empty($_SESSION['user_id'])) {
  header("Location: /DreamCollege/public/login.php");
  exit;
}

$userId = $_SESSION['user_id'];
$collegeId = (int)($_POST['college_id'] ?? 0);

if ($collegeId <= 0) {
  header("Location: /DreamCollege/public/index.php");
  exit;
}

// Create bookmarks table if not exists
$pdo->exec("CREATE TABLE IF NOT EXISTS bookmarks (
  id INT AUTO_INCREMENT PRIMARY KEY,
  user_id INT NOT NULL,
  college_id INT NOT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  UNIQUE(user_id, college_id)
)");

// Insert bookmark
$stmt = $pdo->prepare("INSERT IGNORE INTO bookmarks (user_id, college_id) VALUES (?, ?)");
$stmt->execute([$userId, $collegeId]);

header("Location: /DreamCollege/public/dashboard.php");
exit;
