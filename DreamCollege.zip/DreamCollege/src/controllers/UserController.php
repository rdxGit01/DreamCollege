<?php
require_once __DIR__ . '/../models/UserModel.php';

class UserController {

    private $userModel;

    public function __construct() {
        $this->userModel = new UserModel();
    }

    public function getUserById($id) {
        return $this->userModel->getById($id);
    }
}
