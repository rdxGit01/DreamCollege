<?php
require_once __DIR__ . '/../services/FilterService.php';

require_once __DIR__ . '/../models/CollegeModel.php';

class CollegeController {

    private $collegeModel;

    public function getFilteredColleges($params) {
        $service = new FilterService();
        return $service->applyFilters($params);
    }


    public function __construct() {
        $this->collegeModel = new CollegeModel();
    }

    public function getAllColleges() {
        return $this->collegeModel->getAll();
    }

    public function getCollegeById($id) {
        return $this->collegeModel->getById($id);
    }
}
