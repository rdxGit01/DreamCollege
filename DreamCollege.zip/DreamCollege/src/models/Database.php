<?php
require_once __DIR__ . '/../../config/db_mysql.php';

class Database {
    protected $conn;

    public function __construct() {
        global $conn;
        $this->conn = $conn;
    }
}
