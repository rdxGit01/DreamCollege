<?php
require_once 'Database.php';

class UserModel extends Database {

    public function getById($id) {
        $id = intval($id);
        $sql = "SELECT * FROM users WHERE id = $id";
        return mysqli_query($this->conn, $sql);
    }
}
