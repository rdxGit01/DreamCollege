<?php
require_once 'Database.php';

class CollegeModel extends Database {

    public function getAll() {
        $sql = "SELECT * FROM colleges";
        return mysqli_query($this->conn, $sql);
    }

    public function getById($id) {
        $id = intval($id);
        $sql = "SELECT * FROM colleges WHERE id = $id";
        return mysqli_query($this->conn, $sql);
    }
}
