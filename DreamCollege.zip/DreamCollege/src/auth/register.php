<?php
// src/auth/register.php
session_start();
require_once __DIR__ . '/../../config/db_mysql.php';
require_once __DIR__ . '/../models/UserModel.php';

$userModel = new UserModel($pdo);

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  $name = trim($_POST['name'] ?? '');
  $email = trim($_POST['email'] ?? '');
  $password = $_POST['password'] ?? '';
  $confirm = $_POST['confirm'] ?? '';

  if ($name === '' || $email === '' || $password === '') {
    $_SESSION['error'] = "All fields are required.";
    header("Location: /DreamCollege/public/signup.php"); exit;
  }
  if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
    $_SESSION['error'] = "Invalid email.";
    header("Location: /DreamCollege/public/signup.php"); exit;
  }
  if ($password !== $confirm) {
    $_SESSION['error'] = "Passwords do not match.";
    header("Location: /DreamCollege/public/signup.php"); exit;
  }
  if ($userModel->findByEmail($email)) {
    $_SESSION['error'] = "Email already registered.";
    header("Location: /DreamCollege/public/signup.php"); exit;
  }
  $userModel->create($name, $email, $password);
  $_SESSION['success'] = "Account created. Please log in.";
  header("Location: /DreamCollege/public/login.php"); exit;
}
