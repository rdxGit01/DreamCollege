<?php
// src/auth/login.php
session_start();
require_once __DIR__ . '/../../config/db_mysql.php';
require_once __DIR__ . '/../models/UserModel.php';

$userModel = new UserModel($pdo);
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  $email = trim($_POST['email'] ?? '');
  $password = $_POST['password'] ?? '';

  $user = $userModel->findByEmail($email);
  if (!$user || !password_verify($password, $user['password_hash'])) {
    $_SESSION['error'] = "Invalid credentials.";
    header("Location: /DreamCollege/public/login.php"); exit;
  }
  $_SESSION['user_id'] = $user['id'];
  $_SESSION['user_name'] = $user['name'];
  header("Location: /DreamCollege/public/dashboard.php"); exit;
}
