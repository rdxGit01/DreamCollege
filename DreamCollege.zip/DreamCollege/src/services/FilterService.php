<?php
require_once __DIR__ . '/../models/CollegeModel.php';

class FilterService extends Database {

    public function applyFilters($params) {

        $where = [];

        if (!empty($params['search'])) {
            $s = mysqli_real_escape_string($this->conn, $params['search']);
            $where[] = "(name LIKE '%$s%' OR location LIKE '%$s%' OR courses LIKE '%$s%')";
        }

        if (!empty($params['course'])) {
            $course = mysqli_real_escape_string($this->conn, $params['course']);
            $where[] = "courses LIKE '%$course%'";
        }

        if (!empty($params['nirf'])) {
            $where[] = "nirf_rank <= " . intval($params['nirf']);
        }

        if (!empty($params['naac'])) {
            $naac = mysqli_real_escape_string($this->conn, $params['naac']);
            $where[] = "naac_grade = '$naac'";
        }

        if (!empty($params['location'])) {
            $loc = mysqli_real_escape_string($this->conn, $params['location']);
            $where[] = "location LIKE '%$loc%'";
        }

        if (!empty($params['fees'])) {
            $where[] = "fees <= " . intval($params['fees']);
        }

        $sql = "SELECT * FROM colleges";
        if ($where) {
            $sql .= " WHERE " . implode(" AND ", $where);
        }

        return mysqli_query($this->conn, $sql);
    }
}
