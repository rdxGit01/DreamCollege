import express from "express";
import pg from "pg";
import path from "path";
import { fileURLToPath } from "url";
import bcrypt from "bcrypt";

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const port = 4000;
const saltRounds = 10;

// Middleware
app.use(express.urlencoded({ extended: true }));
app.use(express.json());
app.use(express.static(__dirname));

// PostgreSQL
const db = new pg.Client({
  user: "postgres",
  host: "localhost",
  database: "DreamCollege",
  password: "123456@",
  port: 5432,
});

db.connect();

// Routes
app.get("/", (req, res) => {
  res.sendFile(path.join(__dirname, "index.html"));
});

app.get("/login", (req, res) => {
  res.sendFile(path.join(__dirname, "login.html"));
});

app.get("/signup", (req, res) => {
  res.sendFile(path.join(__dirname, "signup.html"));
});

// Signup
app.post("/signup", async (req, res) => {
  const { username, password } = req.body;

  try {
    const check = await db.query(
      "SELECT * FROM users WHERE email=$1",
      [username]
    );

    if (check.rows.length > 0) {
      return res.send("Email already exists");
    }

    const hash = await bcrypt.hash(password, saltRounds);

    await db.query(
      "INSERT INTO users (email, password) VALUES ($1,$2)",
      [username, hash]
    );

    res.sendFile(path.join(__dirname, "dashboard.html"));
  } catch (err) {
    console.error(err);
    res.send("Signup error");
  }
});

// Login
app.post("/login", async (req, res) => {
  const { username, password } = req.body;

  const result = await db.query(
    "SELECT * FROM users WHERE email=$1",
    [username]
  );

  if (result.rows.length === 0) {
    return res.send("User not found");
  }

  const match = await bcrypt.compare(
    password,
    result.rows[0].password
  );

  if (match) {
    res.sendFile(path.join(__dirname, "dashboard.html"));
  } else {
    res.send("Wrong password");
  }
});

app.listen(port, () => {
  console.log(`🚀 Server running on http://localhost:${port}`);
});
